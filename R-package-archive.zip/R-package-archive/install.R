devtools::install("R-package-archive/DLMtool_5.4.3/", dependencies = F)
devtools::install("R-package-archive/MSEtool_1.6.0-edited/", dependencies = F)
devtools::install("R-package-archive/gfdlm_0.1.9001", dependencies = F)

rstudioapi::restartSession()
