
# tinyErr method is defined in MOM_object.R (placed after MOM definition)
tinyErr_MOM <- function(MOM, obs = TRUE, imp = TRUE, proc = TRUE, grad = TRUE, silent = FALSE) {
  if (!inherits(MOM, "MOM"))
    stop("Object must be class `MOM`", call. = FALSE)
  tinyErr(MOM, obs = obs, imp = imp, proc = proc, grad = grad, silent = silent)
}


