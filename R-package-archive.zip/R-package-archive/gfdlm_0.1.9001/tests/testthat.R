library(testthat)
library(DLMtool)
library(gfdlm)

test_check("gfdlm")
