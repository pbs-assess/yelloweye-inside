# gfdlm

<!-- badges: start -->
[![R-CMD-check](https://github.com/pbs-assess/gfdlm/workflows/R-CMD-check/badge.svg)](https://github.com/pbs-assess/gfdlm/actions)
[![Codecov test coverage](https://codecov.io/gh/pbs-assess/gfdlm/branch/master/graph/badge.svg)](https://codecov.io/gh/pbs-assess/gfdlm?branch=master)
<!-- badges: end -->

Tools for creating, modifying, and plotting DLMtool inputs and outputs from PBS groundfish data
