#' Example simple operating model
#'
#' An object of class [OM-class] with nsim set to 3
"om"
