#' Example simple MSE
#'
#' An object of class [MSE-class] for examples
"mse_example"
